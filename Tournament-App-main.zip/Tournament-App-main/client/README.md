Front-End Skills:
    1- React.js (React Router Dom , React Redux , Redux Toolkit)
    2- Formik & Yup
    3- Material UI
    4- Google Font
    5- Axios
    6- Js-Cookie
    7- Sweet Alert

Back-End Skills:
    1- Node.js
    2- Express.js
    3- MongoDB
    4- Packages:
        1- Dotenv
        2- Cors
        3- Helmet
        4- Body-Parser
        5- Nodemon
        6- NodeMailer
        7- Json Web Token
        8- Validator
        9- Passport
        10- Cookie Parser
        11- Bcrypt
        12- Axios 